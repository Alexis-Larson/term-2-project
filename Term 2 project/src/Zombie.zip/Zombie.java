import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;


public class Zombie
{
	public static int width = 48, height = 48;
	public static int x = 100, y = 100;
	public static int previousx = 100, previousy = 100;
	public static int 
		centerx = x+(width/2), 
		centery = y+(height/2);
	public static Rectangle rect = new Rectangle(x, y, width, height);
	public static BufferedImage normalimg;
	public static double rotate;

	
	public static int movespeed = 2;

	public Zombie(int x, int y)
	{
		try
		{
			normalimg = ImageIO.read(new File("normalzombie.png"));
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	public static void move()
	{
		rotate = Math.toDegrees(Math.atan2(Player.centerx-centerx, Player.centery-centery));	
	}
}
