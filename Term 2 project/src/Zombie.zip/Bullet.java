import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;


public class Bullet
{

	public int startx;
	public int starty;
	public int size;
	public int z;
	public double angle;
	public double x;
	public double y;
	public double previousx = x;
	public double previousy = y;
	
	public Bullet(int mousex, int mousey)
	{
		startx = Player.centerx;
		starty = Player.centery;
		size = 4;
		z = 0;
		angle = Math.atan2(mousey-starty, mousex-startx);
		x = ((z*5)*Math.cos(angle));
		y = ((z*5)*Math.sin(angle));
		
	}
	public void update()
	{
		z += 12;
		previousx = x;
		previousy = y;
		x = ((z)*Math.cos(angle));
		y = ((z)*Math.sin(angle));
	}

}
