import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;


public class Player 
{
	public static int x = 100, y = 100;
	public static int previousx = 100, previousy = 100;
	public static int width = 48, height = 48;
	public static Rectangle rect = new Rectangle(x, y, width, height);
	public static BufferedImage
		Pistolimg,
		SMGimg,
		Assault_rifleimg,
		Machine_gunimg,
		Bolt_action_rifleimg,
		Semi_Auto_Sniperimg,
		selectedimg;
	
	public static int 
		centerx = x+(width/2), 
		centery = y+(height/2);
	public static int movespeed = 2;
	protected static int movespeed_sprint = 3;
	
	public static int selectedweapon = 0;
	public static int 
		Pistol = 0,
		SMG	= 1,
		Assault_rifle = 2,
		Machine_gun = 3,
		Bolt_action_rifle = 4,
		Semi_Auto_Sniper = 5;
	
	
	public Player()
	{
		try
		{
			Pistolimg = ImageIO.read(new File("player.png"));
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
	}
	public void setplayerimg(int x)
	{
		if(x == 1)selectedimg = Pistolimg;
		if(x == 2)selectedimg = SMGimg;
		if(x == 3)selectedimg = Assault_rifleimg;
		if(x == 4)selectedimg = Machine_gunimg;
		if(x == 5)selectedimg = Bolt_action_rifleimg;
		if(x == 6)selectedimg = Semi_Auto_Sniperimg;		
	}

}
